/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Fatec
 */
public class TesteCliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DadosCliente cliente = new DadosCliente("43567886321", "Lucas", 19);
        System.out.println(cliente.getCpf());
        System.out.println(cliente.getNome());
        System.out.println(Integer.toString(cliente.getIdade()));
    }
    
}
